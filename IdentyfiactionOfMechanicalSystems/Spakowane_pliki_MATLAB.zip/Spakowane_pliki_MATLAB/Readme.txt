## App created by Jakub Nowak and Maciej Mazurkiewicz ##
## Identyfikacja układów mechatronicznych ##
## Kraków 2022 ##
Zipped folder contains:
- AM, FM modulation and demodulation.mlappinstall - installation file for our App
- AM_modulated_signal.mat - example of AM modulated signal to load
- FM_modulated_signal.mat - example of FM modulated signal to load
- example_input_signal.mat  - example of signal to be modulated
- Project_gui_01_05.mlapp - application project file with source code embedded

You can install app by running .mlapinstall file and then it will be available in your apps in MATLAB.
While running it you can not be in a folder which contains .mlapp file.

Second way is to open .mlapp file and then click run. From then you can see the code of app, however some features may not work correctly e.g. displaying of AGH and WiMIR logos.